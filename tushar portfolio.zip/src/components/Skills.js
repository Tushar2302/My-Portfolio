import React from 'react'
const Skills = () => {
  return (
    <section className='min-h-screen bg-bg_light_primary'>
      
    </section>
  )
}

export default Skills
