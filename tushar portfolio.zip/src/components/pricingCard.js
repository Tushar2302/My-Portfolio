import "./pricingcardStyles.css";
import React from 'react'
import { Link } from "react-router-dom";


const pricingCard = () => {
  return (
    <div className="pricing">
      <div className="cardContainer">
        <div className="card">
            <h3></h3>
            <span className="bar"></span>
            <p className="btc"></p>
            
            <Link to="/contact" className="hbvfhv">
            </Link>
        </div>
      </div>
    </div>

    
  )
}

export default pricingCard

