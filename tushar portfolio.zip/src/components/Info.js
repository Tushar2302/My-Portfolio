import React from 'react'

const Info = () => {
  return (
    <div>
      
    </div>
  )
}

export default Info
